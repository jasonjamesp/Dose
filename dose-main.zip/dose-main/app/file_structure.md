## Flutter Project Structure

```text
lib/
├── db/
│   ├── cabinet_db.dart
│   ├── dose_database.dart
│   ├── intake_log_db.dart
│   ├── profile_db.dart
│   └── README_DB.md
├── models/
│   ├── cabinet_model.dart
│   ├── extensions.dart
│   ├── intake_model.dart
│   ├── medicine_category.dart
│   └── profile_model.dart
├── pages/
│   ├── about_page.dart
│   ├── add_menu_page.dart
│   ├── analytics_page.dart
│   ├── cabinet_page.dart
│   ├── edit_profile_page.dart
│   ├── history_page.dart
│   ├── home_page.dart
│   ├── onboarding_page.dart
│   ├── profile_details_page.dart
│   ├── profile_page.dart
│   ├── settings_page.dart
│   └── support_page.dart
├── services/
│   ├── alarm_ring_service.dart
│   ├── alarm_service.dart
│   ├── analytics_service.dart
│   ├── app_bootstrapper.dart
│   ├── backup_service.dart
│   ├── google_drive_service.dart (Groundwork for Google Drive sync)
│   ├── intake_service.dart
│   ├── notification_service.dart
│   ├── snooze_service.dart
│   ├── theme_service.dart
│   └── widget_service.dart
├── widgets/
│   └── dose_card.dart
├── dose.dart
└── main.dart
```

## Native Alarm System


The architecture is located at `android/app/src/main/kotlin/org/orbitronhd/dose/alarm/`:

```text
alarm/
├── AlarmData.kt               
├── AlarmForegroundService.kt  
├── AlarmReceiver.kt           
├── AlarmScheduler.kt          
├── AlarmStorage.kt            
├── BootReceiver.kt            
└── DoseAlarmPlugin.kt         
```